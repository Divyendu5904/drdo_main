<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(401); // Unauthorized
    echo json_encode(['success' => false, 'message' => 'User not authenticated.']);
    exit;
}


header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Only POST method is allowed.']);
    exit;
}

$name = $_POST['name'] ?? null;
$ip_address = $_POST['ip_address'] ?? null;
$status = isset($_POST['status']) ? (int)$_POST['status'] : 1;
$reason = $_POST['reason'] ?? '';
$building_id = $_POST['building_id'] ?? null; // New field

// Validation
if (empty($name) || empty($ip_address) || empty($building_id)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Name, IP address, and Building are required.']);
    exit;
}

if (!filter_var($ip_address, FILTER_VALIDATE_IP)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid IP address format.']);
    exit;
}

if ($status === 0 && empty($reason)) {
    $reason = 'Manually set to inactive.';
}

try {
    $pdo = new PDO('sqlite:' . __DIR__ . '/../data/network.db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Insert into switches table with the new building_id
    $stmt = $pdo->prepare("INSERT INTO switches (name, ip_address, status, reason, building_id) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$name, $ip_address, $status, $reason, $building_id]);
    $switch_id = $pdo->lastInsertId();

    $log_stmt = $pdo->prepare("INSERT INTO logs (switch_id, change_type, new_value) VALUES (?, ?, ?)");
    $log_stmt->execute([$switch_id, 'new_device', "Added '{$name}' with IP {$ip_address}"]);

    echo json_encode(['success' => true, 'message' => 'Device added successfully.']);

} catch (PDOException $e) {
    if ($e->getCode() == 23000) {
        http_response_code(409);
        echo json_encode(['success' => false, 'message' => 'Error: IP address already exists.']);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
}
?>
