<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(401); // Unauthorized
    echo json_encode(['success' => false, 'message' => 'User not authenticated.']);
    exit;
}


header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Only POST method is allowed.']);
    exit;
}

// --- Get POST data ---
$device_id = $_POST['device_id'] ?? null;

// --- Validation ---
if (empty($device_id)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Device ID is required.']);
    exit;
}

try {
    $pdo = new PDO('sqlite:' . __DIR__ . '/../data/network.db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // First, get the name of the device for logging before we delete it
    $name_stmt = $pdo->prepare("SELECT name FROM switches WHERE id = ?");
    $name_stmt->execute([$device_id]);
    $device = $name_stmt->fetch(PDO::FETCH_ASSOC);
    $device_name = $device ? $device['name'] : 'Unknown Device';

    // Prepare the DELETE statement
    $stmt = $pdo->prepare("DELETE FROM switches WHERE id = ?");
    $stmt->execute([$device_id]);

    // Check if any row was actually deleted
    if ($stmt->rowCount() > 0) {
        // Log the deletion. Note: switch_id is set to null as it no longer exists.
        $log_stmt = $pdo->prepare("INSERT INTO logs (switch_id, change_type, new_value) VALUES (?, ?, ?)");
        $log_stmt->execute([null, 'device_delete', "Device '${device_name}' was deleted."]);

        echo json_encode(['success' => true, 'message' => 'Device deleted successfully.']);
    } else {
        http_response_code(404); // Not Found
        echo json_encode(['success' => false, 'message' => 'Device not found.']);
    }

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
