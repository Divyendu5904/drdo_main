<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'User not authenticated.']);
    exit;
}

header('Content-Type: application/json');

try {
    $pdo = new PDO('sqlite:' . __DIR__ . '/../data/network.db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch all upcoming or currently active maintenance windows
    $stmt = $pdo->query("
        SELECT 
            m.id, m.device_id, m.start_time, m.end_time, m.reason, m.created_by,
            s.name as device_name
        FROM maintenance_windows m
        JOIN switches s ON m.device_id = s.id
        WHERE m.end_time > CURRENT_TIMESTAMP
        ORDER BY m.start_time ASC
    ");
    
    $windows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $windows]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'An error occurred: ' . $e->getMessage()]);
}
?>
