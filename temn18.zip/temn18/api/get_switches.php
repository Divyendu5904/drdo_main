<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'User not authenticated.']);
    exit;
}

header('Content-Type: application/json');

function get_ping_result($ip_address, $timeout = 1) {
    $latency = null;
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        $command = "ping -n 1 -w " . ($timeout * 1000) . " " . escapeshellarg($ip_address);
        exec($command, $output, $status);
        if ($status === 0) {
            foreach ($output as $line) {
                if (strpos($line, 'time=') !== false || strpos($line, 'Time=') !== false) {
                    preg_match('/time(?:=|<)(\d+)/', $line, $matches);
                    $latency = isset($matches[1]) ? (int)$matches[1] : null;
                    break;
                }
            }
            return ['status' => true, 'latency' => $latency];
        }
    } else {
        $command = "ping -c 1 -W " . $timeout . " " . escapeshellarg($ip_address);
        exec($command, $output, $status);
        if ($status === 0) {
            foreach ($output as $line) {
                if (strpos($line, 'time=') !== false) {
                    preg_match('/time=([\d\.]+)/', $line, $matches);
                    $latency = isset($matches[1]) ? round((float)$matches[1]) : null;
                    break;
                }
            }
            return ['status' => true, 'latency' => $latency];
        }
    }
    return ['status' => false, 'latency' => null];
}

try {
    $pdo = new PDO('sqlite:' . __DIR__ . '/../data/network.db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // --- Prepared Statements ---
    $log_stmt = $pdo->prepare("INSERT INTO logs (switch_id, change_type, old_value, new_value) VALUES (?, ?, ?, ?)");
    $update_device_stmt = $pdo->prepare("UPDATE switches SET status = ?, reason = ? WHERE id = ?");
    $create_alert_stmt = $pdo->prepare("INSERT INTO network_alerts (device_id, title, description) VALUES (?, ?, ?)");
    $resolve_alert_stmt = $pdo->prepare("UPDATE network_alerts SET status = 'resolved', resolved_at = CURRENT_TIMESTAMP WHERE device_id = ? AND status = 'active'");
    $ping_log_stmt = $pdo->prepare("INSERT INTO ping_logs (device_id, latency_ms, status) VALUES (?, ?, ?)");
    $maintenance_check_stmt = $pdo->prepare("SELECT id FROM maintenance_windows WHERE device_id = ? AND start_time <= CURRENT_TIMESTAMP AND end_time >= CURRENT_TIMESTAMP");

    // --- Main Logic ---
    $buildings_stmt = $pdo->query("SELECT id, name, location FROM buildings ORDER BY name ASC");
    $buildings = $buildings_stmt->fetchAll(PDO::FETCH_ASSOC);
    $grouped_data = [];
    foreach ($buildings as $building) {
        $grouped_data[$building['id']] = ['building_name' => $building['name'], 'building_location' => $building['location'], 'devices' => []];
    }

    $switches_stmt = $pdo->query("SELECT id, name, ip_address, status, reason, building_id FROM switches");
    $switches = $switches_stmt->fetchAll(PDO::FETCH_ASSOC);
    $unassigned_devices = [];

    foreach ($switches as &$switch) {
        // --- NEW: Maintenance Mode Check ---
        $maintenance_check_stmt->execute([$switch['id']]);
        $is_in_maintenance = $maintenance_check_stmt->fetchColumn();

        if ($is_in_maintenance) {
            $switch['status'] = 2; // Special status for maintenance
            $switch['reason'] = 'In Maintenance';
            // We don't ping or create alerts for a device in maintenance
        } else {
            $ping_result = get_ping_result($switch['ip_address']);
            $is_alive = $ping_result['status'];
            $latency = $ping_result['latency'];
            $current_db_status = (int)$switch['status'];

            $ping_log_stmt->execute([$switch['id'], $latency, $is_alive ? 1 : 0]);

            if ($is_alive && $current_db_status !== 1) {
                $new_reason = "Online - {$latency}ms";
                $update_device_stmt->execute([1, $new_reason, $switch['id']]);
                $log_stmt->execute([$switch['id'], 'status_change', 'Inactive', 'Active']);
                $resolve_alert_stmt->execute([$switch['id']]);
                $switch['status'] = 1;
                $switch['reason'] = $new_reason;
            } elseif (!$is_alive && $current_db_status !== 0) {
                $new_reason = 'Ping failed: Host unreachable';
                $update_device_stmt->execute([0, $new_reason, $switch['id']]);
                $log_stmt->execute([$switch['id'], 'status_change', 'Active', 'Inactive']);
                $create_alert_stmt->execute([$switch['id'], "Device Down: " . $switch['name'], $new_reason]);
                $switch['status'] = 0;
                $switch['reason'] = $new_reason;
            } elseif ($is_alive) {
                $switch['reason'] = "Online - {$latency}ms";
            }
        }

        if (isset($switch['building_id']) && isset($grouped_data[$switch['building_id']])) {
            $grouped_data[$switch['building_id']]['devices'][] = $switch;
        } else {
            $unassigned_devices[] = $switch;
        }
    }
    
    if (!empty($unassigned_devices)) {
        $grouped_data['unassigned'] = ['building_name' => 'Unassigned Devices', 'building_location' => '', 'devices' => $unassigned_devices];
    }

    echo json_encode(['success' => true, 'data' => array_values($grouped_data)]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'An error occurred: ' . $e->getMessage()]);
}
?>
