<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'User not authenticated.']);
    exit;
}

header('Content-Type: application/json');

try {
    $pdo = new PDO('sqlite:' . __DIR__ . '/../data/network.db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch the 20 most recently resolved alerts
    $stmt = $pdo->query("
        SELECT 
            a.id, 
            a.title, 
            a.description, 
            a.created_at, 
            a.resolved_at,
            s.name as device_name
        FROM network_alerts a
        JOIN switches s ON a.device_id = s.id
        WHERE a.status = 'resolved'
        ORDER BY a.resolved_at DESC
        LIMIT 20
    ");
    
    $alerts = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $alerts]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'An error occurred: ' . $e->getMessage()]);
}
?>
