
<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(401); // Unauthorized
    echo json_encode(['success' => false, 'message' => 'User not authenticated.']);
    exit;
}

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Only POST method is allowed.']);
    exit;
}

// --- Get POST data ---
$device_id = $_POST['device_id'] ?? null;
$name = $_POST['name'] ?? null;
$ip_address = $_POST['ip_address'] ?? null;
$building_id = $_POST['building_id'] ?? null;

// --- Validation ---
if (empty($device_id) || empty($name) || empty($ip_address) || empty($building_id)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Device ID, Name, IP Address, and Building are all required.']);
    exit;
}

if (!filter_var($ip_address, FILTER_VALIDATE_IP)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid IP address format.']);
    exit;
}

try {
    $pdo = new PDO('sqlite:' . __DIR__ . '/../data/network.db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Prepare the UPDATE statement
    $stmt = $pdo->prepare(
        "UPDATE switches SET name = ?, ip_address = ?, building_id = ? WHERE id = ?"
    );

    // Execute the update
    $stmt->execute([$name, $ip_address, $building_id, $device_id]);

    // Log the change
    $log_stmt = $pdo->prepare("INSERT INTO logs (switch_id, change_type, new_value) VALUES (?, ?, ?)");
    $log_stmt->execute([$device_id, 'device_update', "Device '${name}' was updated."]);

    echo json_encode(['success' => true, 'message' => 'Device updated successfully.']);

} catch (PDOException $e) {
    // Check for unique constraint violation on IP address
    if ($e->getCode() == 23000) {
        http_response_code(409); // Conflict
        echo json_encode(['success' => false, 'message' => 'Error: Another device already has this IP address.']);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
}
?>
