<?php
// File: /api/get_logs.php

header('Content-Type: application/json');

try {
    // Database connection
    $pdo = new PDO('sqlite:' . __DIR__ . '/../data/network.db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch the last 20 log entries, most recent first, and include the device name
    $stmt = $pdo->query("
        SELECT 
            l.id, 
            l.change_type, 
            l.old_value, 
            l.new_value, 
            l.timestamp, 
            s.name as device_name 
        FROM logs l
        LEFT JOIN switches s ON l.switch_id = s.id
        ORDER BY l.timestamp DESC 
        LIMIT 20
    ");
    
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $logs]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
