<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'User not authenticated.']);
    exit;
}

header('Content-Type: application/json');

$device_id = $_GET['device_id'] ?? null;

if (empty($device_id)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Device ID is required.']);
    exit;
}

try {
    $pdo = new PDO('sqlite:' . __DIR__ . '/../data/network.db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch ping logs for the specific device from the last 24 hours
    $stmt = $pdo->prepare("
        SELECT timestamp, latency_ms, status 
        FROM ping_logs 
        WHERE device_id = ? AND timestamp >= datetime('now', '-24 hours')
        ORDER BY timestamp ASC
    ");
    $stmt->execute([$device_id]);
    $history = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $history]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'An error occurred: ' . $e->getMessage()]);
}
?>
